# 🤖 Lokit AI – Personal AI Chatbot

A RAG-powered personal AI assistant that answers questions about **Lokit Patidar** — his skills, projects, education, achievements, and career goals.

Built with **LangChain · FAISS · Sentence-Transformers · Groq API · Streamlit**.

---

## 📁 Project Structure

```
lokit_ai/
├── backend/
│   ├── __init__.py        # Makes backend a Python package
│   ├── embed_data.py      # Build & save the FAISS vector index
│   └── chatbot.py         # RAG pipeline + ask_bot() function
│
├── knowledge_base/        # Plain-text files about Lokit
│   ├── about_me.txt
│   ├── skills.txt
│   ├── projects.txt
│   ├── education.txt
│   ├── personality.txt
│   ├── achievements.txt
│   └── goals.txt
│
├── vector_db/             # Auto-created by embed_data.py
│   ├── index.faiss
│   └── index.pkl
│
├── app.py                 # Streamlit frontend
├── requirements.txt
├── .env.example
└── README.md
```

---

## ⚙️ Setup & Installation

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/lokit-ai.git
cd lokit-ai
```

### 2. Create and activate a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set up your API key
```bash
cp .env.example .env
# Edit .env and add your GROQ_API_KEY
# Get a free key at https://console.groq.com
```

---

## 🚀 Running the Project

### Step 1 – Build the vector database  *(run once)*
```bash
python backend/embed_data.py
```
This loads all `.txt` files from `knowledge_base/`, generates embeddings, and saves the FAISS index to `vector_db/`.

### Step 2 – Start the Streamlit app
```bash
streamlit run app.py
```

Open your browser at **http://localhost:8501** 🎉

---

## 🔧 How It Works

```
User Question
     │
     ▼
[Embedding Model]  sentence-transformers/all-MiniLM-L6-v2
     │  (encodes question → 384-dim vector)
     ▼
[FAISS Retriever]  cosine similarity search → top-5 chunks
     │
     ▼
[Prompt Template]  fills context + question into LLM prompt
     │
     ▼
[Groq LLM]  gemma2-9b-it  →  generates grounded answer
     │
     ▼
Plain-text answer displayed in Streamlit chat UI
```

---

## 🔌 Frontend Integration

In `app.py`, just import and call:

```python
from backend.chatbot import ask_bot

answer = ask_bot("What are Lokit's skills?")
st.write(answer)
```

---

## 🔄 Swapping the LLM

Open `backend/chatbot.py` and replace `_create_llm()`:

```python
# Ollama (local, no API key)
from langchain_ollama import ChatOllama
return ChatOllama(model="llama3", temperature=0.2)

# OpenAI
from langchain_openai import ChatOpenAI
return ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
```

---

## 📝 Updating the Knowledge Base

1. Edit or add `.txt` files in `knowledge_base/`
2. Re-run: `python backend/embed_data.py`
3. Restart the Streamlit app

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| LLM | Groq API – Gemma 2 9B |
| Embeddings | sentence-transformers/all-MiniLM-L6-v2 |
| Vector DB | FAISS (CPU) |
| RAG Framework | LangChain |
| Frontend | Streamlit |
| Language | Python 3.10+ |

---

*Built with ❤️ by Lokit Patidar*
